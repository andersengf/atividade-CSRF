package com.example.csrf_lab_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsrfLabJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
